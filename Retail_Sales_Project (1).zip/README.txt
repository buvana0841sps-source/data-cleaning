Retail Sales Data Analysis Project

Steps:
1. Download dataset from Kaggle
2. Run database.sql in MySQL
3. Run analysis.py in Python
4. View results and charts

Tools Used:
- Python (Pandas, Matplotlib)
- SQL
- Excel
